// JavaScript Document
var html='<div class="carbonads"><div id="zlogo1" class="zlogo1">凵</div><div id="zlogo2" class="zlogo2">刂</div>Zoomla!逐浪CMS-中国最早引入Bootstrap，基于dotNET大数据全栈高端门户系统，集成电商\微信OA\小程序\教育\考试诸多功能。<a href="http://www.z01.com/pub" class="btn btn-primary btn-sm" target="_blank">免费下载</a></div>'
document.write(html);

/*
<div class="carbonads">
<div id="zlogo1" class="zlogo1">凵</div><div id="zlogo2" class="zlogo2">刂</div>Zoomla!逐浪CMS-中国最早引入Bootstrap，基于dotNET大数据全栈高端门户系统，集成电商\微信OA\小程序\教育\考试诸多功能。<a href="http://www.z01.com/pub" class="btn btn-primary btn-sm" target="_blank">免费下载</a>
</div>



*/